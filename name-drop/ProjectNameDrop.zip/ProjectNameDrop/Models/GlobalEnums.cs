﻿namespace ProjectNameDrop.Models
{
    public enum GlobalEnums
    {

    }
}
